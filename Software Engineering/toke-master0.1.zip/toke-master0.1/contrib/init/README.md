Sample configuration files for:
```
SystemD: toked.service
Upstart: toked.conf
OpenRC:  toked.openrc
         toked.openrcconf
CentOS:  toked.init
macOS:    org.toke.toked.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
